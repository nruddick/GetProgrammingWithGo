package main

import "fmt"

func main() {
	var distance int = 56e6
	distance = 401e6

	fmt.Println(distance)
}
