package main

func main() {
	var weight = 154.0
	weight -= 2
}
