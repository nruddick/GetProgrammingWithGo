package main

func main() {
	var weight = 149.0
	weight = weight * 0.3783
	weight *= 0.3783
}
