package main

import "fmt"

func main() {
	third := 1.0 / 3
	fmt.Printf("%f\n", third)
	fmt.Printf("%7.4f\n", third)
	fmt.Printf("%06.2f\n", third)
}
