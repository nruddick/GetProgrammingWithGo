package main

import "fmt"

func main() {
	var price float64
	fmt.Println(price)
}
