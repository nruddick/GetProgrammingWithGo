# Get Programming with Go

[![CircleCI](https://circleci.com/gh/nathany/get-programming-with-go.svg?style=svg)](https://circleci.com/gh/nathany/get-programming-with-go)

Available from Manning Publications [https://www.manning.com/books/get-programming-with-go](https://manning.com/books/get-programming-with-go?a_aid=nathany&a_bid=53f68821).

Try out these examples in The Go Playground: https://play.golang.org

If you downloaded this code from the Manning website, you can browse the latest version online at: https://github.com/nathany/get-programming-with-go.

### Contributing

Feel free to open an issue or ask questions on the Manning Forums: https://forums.manning.com/forums/get-programming-with-go.

[![Become a Patron](https://c5.patreon.com/external/logo/become_a_patron_button.png)](https://www.patreon.com/nathany)
